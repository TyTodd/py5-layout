class TextManager:
    def __init__(self):
        raise NotImplementedError(f"{self.__class__.__name__} is not yet implemented.")
