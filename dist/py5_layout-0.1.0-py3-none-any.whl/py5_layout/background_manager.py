class BackgroundManager:
    def __init__(self):
        pass
    
